import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service/auth';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [FormsModule],
  standalone: true,
  templateUrl: './register.html',
  styleUrls:  ['./register.css'], 
})
export class RegisterComponent {

user = {
    userName: '',
    password: '',
    confirmPassword: ''
  };

  constructor(private auth: AuthService, private router: Router) {}

  register() {
    this.auth.register(this.user).subscribe({
      next: () => alert('Registered successfully'),
      error: err => alert(err.error)
    });
  }

  goToLogin(){
    this.router.navigate(['/login']);
  }
}
