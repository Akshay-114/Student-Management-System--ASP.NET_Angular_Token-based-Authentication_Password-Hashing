import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../service/user.service/user';
import { User } from '../service/user.service/user.model'
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ChangeDetectorRef } from '@angular/core'; 

@Component({
  selector: 'app-courses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './courses.html',
  styleUrl: './courses.css'
})
export class CoursesComponent implements OnInit {

  users: User[] = [];
  selectedUser: User | null = null;

  constructor(private userService: UserService,
    private router: Router,
    private cd:ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadUsers();
    this.cd.detectChanges()
  }

  loadUsers() {
    this.userService.getUsers().subscribe(data => {
      this.users = data;
      this.cd.detectChanges()
    });
  }

  edit(user: User) {
    this.userService.setSelectedUser(user);
    this.router.navigate(['dashboard/form']);
    this.loadUsers();
  }

  cancel() {
    this.selectedUser = null;
  }

delete(user: User) {
  if (user.id==null) return;
  const id = user.id;

  Swal.fire({
    title: 'Are you sure?',
    text: 'This student record will be permanently deleted!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Yes, delete it!',
  }).then(result => {
    if (result.isConfirmed) {
      this.userService.deleteUser(id).subscribe({
        next: () => {
          this.users = this.users.filter(u => u.id !== user.id);
          this.cd.detectChanges()
          Swal.fire(
            'Deleted!',
            'Student record has been removed.',
            'success'
          );
        },
        error: () => {
          Swal.fire(
            'Error',
            'Unable to delete student.',
            'error'
          );
        }
      });
    }
  });
}
}