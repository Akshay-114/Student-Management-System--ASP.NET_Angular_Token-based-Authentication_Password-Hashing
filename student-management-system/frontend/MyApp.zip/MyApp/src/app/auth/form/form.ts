import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service/user';
import { User } from '../service/user.service/user.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './form.html',
  styleUrls: ['./form.css']
})
export class FormComponent implements OnInit {

  user: User = {
    userName: '',
    email: '',
    department: '',
    phone: '',
    address: '',
    gender: ''
  };

  isEditMode = false;
  isSaving = false;

  constructor(private userService: UserService,
    private router: Router
  ) {}

  ngOnInit() {
    this.userService.selectedUser$.subscribe(user => {
      if (user) {
        this.user = { ...user };
        this.isEditMode = true;
      }
    });
  }

  save() {
  if (this.isSaving) return;
  this.isSaving = true;

  const request$ = this.isEditMode
    ? this.userService.updateUser(this.user)
    : this.userService.addUser(this.user);

  request$.subscribe({
    next: () => {
      Swal.fire({
        icon: 'success',
        title: this.isEditMode ? 'Updated!' : 'Saved!',
        text: 'Student details saved successfully.',
        timer: 1400,
        showConfirmButton: false
      }).then(() => {
        this.isSaving = false;
        this.userService.clearSelectedUser();
        this.router.navigate(['/dashboard/courses']);
      });
    },
    error: () => {
      this.isSaving = false;
      Swal.fire(
        'Error',
        'Failed to save student details.',
        'error'
      );
    }
  });
}

  resetForm() {
    this.user = {
      userName: '',
      email: '',
      department: '',
      phone: '',
      address: '',
      gender: ''
    };
    this.isEditMode = false;
  }
}