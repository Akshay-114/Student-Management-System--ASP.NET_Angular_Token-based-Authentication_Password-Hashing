import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  userName: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
   private apiUrl = 'https://localhost:7214/api/auth' ;

   constructor(private http: HttpClient){}

   //Register
    register(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, data);
  }

   //Login
  login(user: { userName: string; password: string }): Observable<AuthResponse> {
  return this.http.post<AuthResponse>(`${this.apiUrl}/login`, user);
}
   //Refresh token
   refreshToken(tokens:any){
  return this.http.post(`${this.apiUrl}/refresh`, tokens);
  }

  //Logout
  logout(){
  return this.http.post(`${this.apiUrl}/logout`, {});
  }

}
