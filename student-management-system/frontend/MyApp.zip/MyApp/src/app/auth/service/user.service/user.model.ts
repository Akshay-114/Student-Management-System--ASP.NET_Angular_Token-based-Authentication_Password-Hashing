export interface User {
  id?: number;
  userName: string;
  email?: string;
  phone?: string;
  address?: string;
  department?: string;
  gender?: string;
}