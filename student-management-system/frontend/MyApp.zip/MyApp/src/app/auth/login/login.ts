import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service/auth';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class LoginComponent {

  user = {
    userName: '',
    password: ''
  };

  isLoggingIn = false;

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  goToRegister() {
    this.router.navigate(['/register']);
  }

  login() {

    /* Validation */
    if (!this.user.userName || !this.user.password) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Fields',
        timer: 1500,
        text: 'Please enter username and password'
      });
      return;
    }

    if (this.isLoggingIn) return;
    this.isLoggingIn = true;

    /* Loading */
    Swal.fire({
      title: 'Signing in...',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
    });

    this.auth.login(this.user).subscribe({
      next: (res: any) => {
        const accessToken = res.accessToken || res.AccessToken;
        const refreshToken = res.refreshToken || res.RefreshToken;

        if (!accessToken || !refreshToken) {
          this.isLoggingIn = false;
          Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            timer: 1500,
            text: 'Invalid username or password'
            
          });
          return;
        }

        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);

        Swal.fire({
          icon: 'success',
          title: 'Welcome!',
          text: 'Login successful',
          timer: 1500,
          showConfirmButton: false
        }).then(() => {
          this.router.navigate(['/dashboard']);
        });
      },

      error: (err) => {
        this.isLoggingIn = false;

        let message = 'Something went wrong';

        if (err.status === 401) {
          message = 'Invalid username or password';
        } else if (err.status === 0) {
          message = 'Server not reachable';
        }

        Swal.fire({
          icon: 'error',
          title: 'Login Failed',
          timer: 1500,
          text: message
        });
      }
    });
  }
}