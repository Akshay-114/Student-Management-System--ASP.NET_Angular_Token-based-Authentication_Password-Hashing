import { Routes } from '@angular/router';
import { authGuard } from './auth/guards/auth-guard';
import { FormComponent } from './auth/form/form'; 
import { HomeComponent } from './auth/home/home';
import { CoursesComponent } from './auth/courses/courses';

export const routes: Routes = [

  {
    path: 'login',
    loadComponent: () =>
      import('./auth/login/login')
        .then(m => m.LoginComponent)
  },

  {
    path: 'register',
    loadComponent: () =>
      import('./auth/register/register')
        .then(m => m.RegisterComponent)
  },

  // Protected route -> cannot navigate without successful login
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./auth/dashboard/dashboard')
        .then(m => m.DashboardComponent),
        children: [
          {
            path: 'home',
            component: HomeComponent
          },
      {
        path: 'form',
        component: FormComponent
      },
      {
        path: 'courses',
        component: CoursesComponent
      },
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      }
    ]
  },
  
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  { 
    path: '**',
    redirectTo: 'login'
  }
  
];