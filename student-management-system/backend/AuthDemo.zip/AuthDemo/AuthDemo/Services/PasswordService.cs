﻿using AuthDemo.Models;
using Microsoft.AspNetCore.Identity;

namespace AuthDemo.Services
{
    public class PasswordService
    {
        private PasswordHasher<AppUser> _hasher = new();

        public string HashPassword(AppUser user, string password)
        {
            return _hasher.HashPassword(user,password);
        }

        public bool VerifyPassword(AppUser user, string hash, string password)
        {
            var result = _hasher.VerifyHashedPassword(user,hash,password);
            return result == PasswordVerificationResult.Success;
        }
    }
}
