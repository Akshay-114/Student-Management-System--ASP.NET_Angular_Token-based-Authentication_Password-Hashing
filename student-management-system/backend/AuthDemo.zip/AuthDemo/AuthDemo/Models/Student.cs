﻿using System.ComponentModel.DataAnnotations;

namespace AuthDemo.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required]
        public string UserName { get; set; } = string.Empty;

        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? Address { get; set; }
        public string? Department { get; set; }
        public string? Gender { get; set; }
    }
}
